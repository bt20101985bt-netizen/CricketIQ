ICONS FOLDER — Add your app icons here
=======================================
Required files:
  icon-72.png   (72x72 px)
  icon-96.png   (96x96 px)
  icon-192.png  (192x192 px)  ← most important
  icon-512.png  (512x512 px)  ← most important

HOW TO CREATE ICONS (free, mobile-friendly):
1. Go to realfavicongenerator.net on your phone
2. Upload any square image (your logo or a cricket ball 🏏)
3. Download the package
4. Copy the PNG files into this icons/ folder
5. Re-upload to Netlify

WITHOUT ICONS: The app still works perfectly.
Icons are only needed for the "Install App" (PWA) feature.
