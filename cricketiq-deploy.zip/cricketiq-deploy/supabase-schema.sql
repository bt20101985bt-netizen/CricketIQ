-- ================================================================
-- CricketIQ Pro - Supabase Database Schema
-- HOW TO USE:
-- 1. Go to supabase.com → Your Project → SQL Editor
-- 2. Click "New Query"
-- 3. Copy ALL text below and paste it in
-- 4. Click "Run" (green button)
-- 5. You should see "Success. No rows returned"
-- ================================================================

-- Enable UUID support
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── SUBSCRIPTIONS: tracks Pro users ──
CREATE TABLE IF NOT EXISTS subscriptions (
  id                   UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id              UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email                TEXT NOT NULL,
  status               TEXT NOT NULL DEFAULT 'inactive',
  plan                 TEXT NOT NULL DEFAULT 'monthly',
  expires_at           TIMESTAMPTZ,
  razorpay_order_id    TEXT,
  razorpay_payment_id  TEXT,
  amount_paid          INTEGER,
  created_at           TIMESTAMPTZ DEFAULT NOW(),
  updated_at           TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_subs_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subs_status  ON subscriptions(status);

-- ── PREDICTIONS: every match prediction saved ──
CREATE TABLE IF NOT EXISTS predictions (
  id               UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id          UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  team1            TEXT NOT NULL,
  team2            TEXT NOT NULL,
  prob_team1       INTEGER,
  prob_team2       INTEGER,
  confidence       INTEGER,
  format           TEXT DEFAULT 'T20',
  venue            TEXT,
  predicted_winner TEXT,
  actual_winner    TEXT,
  was_correct      BOOLEAN,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pred_user_id ON predictions(user_id);
CREATE INDEX IF NOT EXISTS idx_pred_created ON predictions(created_at DESC);

-- ── PDF PURCHASES: tracks ₹19 PDF sales ──
CREATE TABLE IF NOT EXISTS pdf_purchases (
  id                   UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id              UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  email                TEXT,
  team1                TEXT,
  team2                TEXT,
  amount               INTEGER DEFAULT 1900,
  razorpay_payment_id  TEXT,
  created_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ── PROFILES: auto-created when user signs up ──
CREATE TABLE IF NOT EXISTS profiles (
  id                  UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email               TEXT,
  display_name        TEXT,
  total_predictions   INTEGER DEFAULT 0,
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile on new signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ── SECURITY: users can only see their own data ──
ALTER TABLE subscriptions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE predictions    ENABLE ROW LEVEL SECURITY;
ALTER TABLE pdf_purchases  ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles       ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own_subscription"  ON subscriptions  FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_predictions"   ON predictions    FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_pdf_purchases" ON pdf_purchases  FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_profile"       ON profiles       FOR ALL USING (auth.uid() = id);

-- ── ADMIN VIEW: your revenue dashboard ──
CREATE OR REPLACE VIEW admin_revenue AS
SELECT
  (SELECT COUNT(*)  FROM auth.users)                                     AS total_users,
  (SELECT COUNT(*)  FROM subscriptions WHERE status = 'active')          AS active_pro_users,
  (SELECT COUNT(*)  FROM subscriptions WHERE plan = 'monthly' AND status = 'active') AS monthly_subs,
  (SELECT COUNT(*)  FROM subscriptions WHERE plan = 'yearly'  AND status = 'active') AS yearly_subs,
  (SELECT COUNT(*)  FROM predictions)                                    AS total_predictions,
  (SELECT COUNT(*)  FROM pdf_purchases)                                  AS total_pdf_sales,
  (SELECT COALESCE(SUM(amount_paid), 0) / 100.0 FROM subscriptions WHERE status = 'active') AS subscription_revenue_inr,
  (SELECT COALESCE(SUM(amount), 0)      / 100.0 FROM pdf_purchases)     AS pdf_revenue_inr;

-- ================================================================
-- DONE! Go back to your index.html and replace:
-- 1. YOUR_PROJECT_ID with your Supabase project ID
-- 2. your-anon-key-here with your Supabase Anon Key
-- Both found at: supabase.com → Your Project → Settings → API
-- ================================================================
